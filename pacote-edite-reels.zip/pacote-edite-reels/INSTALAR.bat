@echo off
title Instalando - Edite Reels com o Claude
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
