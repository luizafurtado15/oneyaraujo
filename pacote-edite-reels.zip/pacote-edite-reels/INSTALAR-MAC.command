#!/bin/bash
# Dois cliques neste arquivo abrem o Terminal e rodam o instalador do Mac.
cd "$(dirname "$0")" || exit 1
bash ./instalar-mac.sh
echo
read -n 1 -s -r -p "Aperte qualquer tecla para fechar esta janela..."
echo
