#!/bin/bash
# Instalador do pacote "Edite Reels com o Claude" para Mac (macOS 12 Monterey ou mais novo, M1/M2/M3/M4 ou Intel).
# NAO pede senha e NAO usa Homebrew: tudo fica na pasta do usuario, entao o proprio Claude consegue rodar.
#   ~/.edite-reels           programas (Node 22, FFmpeg, Python 3.12, Git) vindos do conda-forge
#   ~/hyperframes-student-kit o kit de edicao
#   ~/.venvs/whisper         transcricao local
# Como rodar: pelo Claude ou no Terminal (o link vem do professor):
#   curl -fsSL "<link do Drive>" -o ~/edite-reels.sh && bash ~/edite-reels.sh
# Pode rodar de novo sem problema: o que ja existe e pulado.
set -e
ARQ="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
PACOTE="$(dirname "$ARQ")"
BASE="$HOME/.edite-reels"
ENV="$BASE/env"
BIN="$BASE/bin"
MM="$BASE/micromamba"
KIT="$HOME/hyperframes-student-kit"
VENV="$HOME/.venvs/whisper"
LOG="$HOME/edite-reels-instalacao.log"
PASSO_ATUAL="inicio"
TOTAL=9

# Tudo o que aparece na tela tambem vai para um arquivo, para mandar ao suporte se der erro.
exec > >(tee -a "$LOG") 2>&1
echo "===== $(date) ====="

passo() { PASSO_ATUAL="$1/$TOTAL - $2"; echo; echo "[$1/$TOTAL] $2"; }
para() { echo; echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"; for l in "$@"; do echo "  $l"; done; echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"; exit 1; }
deu_erro() {
  echo
  echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
  echo "  Deu erro no passo [$PASSO_ATUAL]."
  echo "  1. Confira a internet e rode o instalador de novo (ele continua de onde parou)."
  echo "  2. Se o erro repetir, mande para o suporte o arquivo:"
  echo "     $LOG"
  echo "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
}
trap 'deu_erro' ERR
baixa() { curl -fL --retry 3 --retry-delay 3 --connect-timeout 20 -sS -o "$2" "$1"; }

# ---------- Conferencias antes de comecar ----------
[ "$(uname -s)" = "Darwin" ] || para "Este instalador e so para Mac. No Windows use o INSTALAR.bat."
[ "$EUID" -ne 0 ] || para "Nao rode com sudo. Rode de novo sem o sudo."

MACOS="$(sw_vers -productVersion)"
MACOS_MAIOR="${MACOS%%.*}"
# O navegador de render do kit (Chrome 151+) exige macOS 13. No macOS 12 usamos o Chrome 150,
# o ultimo que roda no Monterey (conferido no binario: minimo macOS 12.0, Intel e Apple).
CHROME_MONTEREY="150.0.7871.124"

# Chip de verdade (funciona mesmo se o Terminal estiver em modo Rosetta).
if [ "$(sysctl -in hw.optional.arm64)" = "1" ]; then PLAT="osx-arm64"; CHIP="Apple (M)"; else PLAT="osx-64"; CHIP="Intel"; fi
LIVRE_GB="$(df -g "$HOME" | awk 'NR==2 {print $4}')"

# ---------- Diagnostico (sempre roda primeiro; com --diagnostico so ele roda) ----------
linha() { printf '  %-32s %-26s %s
' "$1" "$2" "$3"; }
tem() { [ -n "$1" ] && echo "PRONTO" || echo "FALTA"; }
versao() { "$@" 2>/dev/null | head -1; }
diagnostico() {
  local ok=1 net=0
  curl -fsS --max-time 15 -o /dev/null https://github.com && net=1
  echo; echo "DIAGNOSTICO"
  if [ "$MACOS_MAIOR" -ge 12 ]; then linha "Sistema" "macOS $MACOS" "OK"; else linha "Sistema" "macOS $MACOS" "PROBLEMA"; ok=0; fi
  linha "Chip" "$CHIP" "OK"
  if [ "${LIVRE_GB:-0}" -ge 5 ]; then linha "Espaco livre" "${LIVRE_GB} GB" "OK"; else linha "Espaco livre" "${LIVRE_GB} GB" "PROBLEMA"; ok=0; fi
  if [ "$net" = 1 ]; then linha "Internet" "ok" "OK"; else linha "Internet" "sem acesso ao github.com" "PROBLEMA"; ok=0; fi
  local n g f p k w sk
  n="$(versao "$ENV/bin/node" --version)"; g="$(versao "$ENV/bin/git" --version | sed 's/^git version //')"
  [ -x "$ENV/bin/ffmpeg" ] && f="ok"; [ -x "$ENV/bin/python3.12" ] && p="ok"
  [ -f "$KIT/package.json" ] && k="ok"; [ -x "$VENV/bin/python" ] && w="ok"; [ -d "$KIT/.claude/skills/reel-oney" ] && sk="ok"
  linha "Node.js" "${n:--}" "$(tem "$n")"; linha "Git" "${g:--}" "$(tem "$g")"; linha "FFmpeg" "${f:--}" "$(tem "$f")"
  linha "Python 3.12" "${p:--}" "$(tem "$p")"; linha "Kit de edicao" "${k:--}" "$(tem "$k")"
  linha "Transcricao (Whisper)" "${w:--}" "$(tem "$w")"; linha "Skills do Oney" "${sk:--}" "$(tem "$sk")"
  echo
  if [ "$ok" = 1 ]; then echo "COMPATIVEL: este Mac pode instalar o kit."; return 0; fi
  echo "NAO COMPATIVEL: resolva os itens com PROBLEMA antes de instalar."
  [ "$MACOS_MAIOR" -ge 12 ] || echo "  Precisa do macOS 12 (Monterey) ou mais novo: Ajustes do Sistema > Geral > Atualizacao de Software."
  [ "${LIVRE_GB:-0}" -ge 5 ] || echo "  Libere pelo menos 5 GB no disco."
  return 1
}
if [ "${1:-}" = "--diagnostico" ]; then trap - ERR; diagnostico || true; exit 0; fi
diagnostico || para "Este Mac nao e compativel (veja o diagnostico acima)."

mkdir -p "$BASE" "$BIN"
echo "Mac: macOS $MACOS, chip $CHIP, ${LIVRE_GB} GB livres. Registro: $LOG"

# ---------- 1. Gerenciador de programas ----------
passo 1 "Gerenciador de programas (micromamba)"
if [ -x "$MM" ] && "$MM" --version >/dev/null 2>&1; then echo "  ok: ja instalado"
else
  baixa "https://github.com/mamba-org/micromamba-releases/releases/latest/download/micromamba-$PLAT" "$MM.tmp"
  chmod +x "$MM.tmp" && mv "$MM.tmp" "$MM"
  echo "  ok: micromamba $("$MM" --version)"
fi

# ---------- 2. Programas base ----------
passo 2 "Programas base (Node 22, FFmpeg, Python 3.12, Git) - uns 5 minutos"
pronto_env() {
  [ -x "$ENV/bin/node" ] && [ -x "$ENV/bin/python3.12" ] && [ -x "$ENV/bin/ffprobe" ] && [ -x "$ENV/bin/git" ] \
    && "$ENV/bin/ffmpeg" -hide_banner -encoders 2>/dev/null | grep -q libx264
}
if pronto_env; then echo "  ok: programas ja instalados"
else
  rm -rf "$ENV"
  # ffmpeg "gpl" = versao com o codificador H.264 (libx264) que o render usa
  "$MM" create -y -q -r "$BASE/mamba" -p "$ENV" -c conda-forge --override-channels \
    "nodejs=22" "python=3.12" "ffmpeg=*=gpl*" git
  "$MM" clean -a -y -q -r "$BASE/mamba" >/dev/null 2>&1 || true
  pronto_env || para "Os programas base nao instalaram direito. Rode o instalador de novo."
fi
# Atalhos so para o que o kit usa (nao troca o python que o aluno ja tenha).
for t in node npm npx ffmpeg ffprobe git; do
  printf '#!/bin/sh\nexec "%s/bin/%s" "$@"\n' "$ENV" "$t" > "$BIN/$t"
  chmod +x "$BIN/$t"
done
export PATH="$BIN:$PATH"
# Grava no perfil do Terminal; sem isso o app do Claude nao acha node/ffmpeg depois.
for perfil in "$HOME/.zprofile" "$HOME/.zshrc" "$HOME/.bash_profile"; do
  [ "$perfil" = "$HOME/.bash_profile" ] && [ ! -f "$perfil" ] && continue
  if ! grep -qs ".edite-reels/bin" "$perfil"; then
    printf '\n# Edite Reels com o Claude (node, ffmpeg)\nexport PATH="$HOME/.edite-reels/bin:$PATH"\n' >> "$perfil"
    echo "  ok: caminho dos programas gravado em $perfil"
  fi
done
echo "  ok: node $(node -v), $(ffmpeg -version | head -1 | cut -d' ' -f1-3)"

# ---------- 3. Kit ----------
passo 3 "Kit de edicao (HyperFrames)"
if [ -d "$KIT" ] && [ ! -f "$KIT/package.json" ]; then
  mv "$KIT" "$KIT.incompleto-$(date +%Y%m%d%H%M%S)"
  echo "  pasta incompleta guardada como $KIT.incompleto-*"
fi
if [ ! -d "$KIT" ]; then
  TMPK="$BASE/kit-download"; rm -rf "$TMPK"; mkdir -p "$TMPK"
  baixa "https://codeload.github.com/nateherkai/hyperframes-student-kit/tar.gz/refs/heads/main" "$TMPK/kit.tgz"
  tar -xzf "$TMPK/kit.tgz" -C "$TMPK"
  mv "$TMPK"/hyperframes-student-kit-* "$KIT"
  rm -rf "$TMPK"
  echo "  ok: kit em $KIT"
else echo "  ok: kit ja existe em $KIT"; fi
cd "$KIT"
if [ -f node_modules/.package-lock.json ] && [ node_modules/.package-lock.json -nt package-lock.json ]; then
  echo "  ok: dependencias ja instaladas"
else
  npm ci --no-audit --no-fund
fi

# ---------- 4. Navegador ----------
passo 4 "Navegador de renderizacao"
if [ "$MACOS_MAIOR" -ge 13 ]; then
  npx --yes hyperframes browser ensure
else
  CPLAT="mac-x64"; [ "$PLAT" = "osx-arm64" ] && CPLAT="mac-arm64"
  CDIR="$BASE/chrome"
  CH="$CDIR/chrome-headless-shell-$CPLAT/chrome-headless-shell"
  if [ -x "$CH" ] && [ "$(cat "$CDIR/versao" 2>/dev/null)" = "$CHROME_MONTEREY" ]; then echo "  ok: Chrome $CHROME_MONTEREY ja instalado (versao para macOS 12)"
  else
    echo "  macOS 12: baixando o Chrome $CHROME_MONTEREY, o ultimo que roda no Monterey..."
    rm -rf "$CDIR"; mkdir -p "$CDIR"
    baixa "https://storage.googleapis.com/chrome-for-testing-public/$CHROME_MONTEREY/$CPLAT/chrome-headless-shell-$CPLAT.zip" "$CDIR/c.zip"
    ditto -x -k "$CDIR/c.zip" "$CDIR" && rm -f "$CDIR/c.zip"
    echo "$CHROME_MONTEREY" > "$CDIR/versao"
  fi
  export HYPERFRAMES_BROWSER_PATH="$CH"
  for perfil in "$HOME/.zprofile" "$HOME/.zshrc" "$HOME/.bash_profile"; do
    [ "$perfil" = "$HOME/.bash_profile" ] && [ ! -f "$perfil" ] && continue
    if ! grep -qs "HYPERFRAMES_BROWSER_PATH" "$perfil"; then
      printf '\n# Edite Reels: navegador de render compativel com macOS 12\nexport HYPERFRAMES_BROWSER_PATH="$HOME/.edite-reels/chrome/chrome-headless-shell-%s/chrome-headless-shell"\n' "$CPLAT" >> "$perfil"
    fi
  done
  "$CH" --headless --disable-gpu --no-sandbox --dump-dom "data:text/html,<p>render-ok</p>" 2>/dev/null | grep -q render-ok \
    || para "O navegador de render nao abriu neste Mac. Mande o arquivo $LOG para o suporte."
  echo "  ok: navegador de render funcionando no macOS $MACOS"
fi

# ---------- 5. Whisper ----------
passo 5 "Transcricao local (Whisper)"
if ! "$VENV/bin/python" -c "import sys" >/dev/null 2>&1; then
  rm -rf "$VENV"; mkdir -p "$(dirname "$VENV")"
  "$ENV/bin/python3.12" -m venv "$VENV"
fi
# --only-binary: so versoes prontas; nunca tenta compilar (o Mac nao tem compilador sem senha)
"$VENV/bin/python" -m pip install --quiet --disable-pip-version-check --only-binary=:all: --upgrade pip
"$VENV/bin/python" -m pip install --quiet --disable-pip-version-check --only-binary=:all: --upgrade faster-whisper onnxruntime
# /vsl: rastreio do rosto para a legenda que segue a cabeca (se falhar, o resto continua funcionando)
"$VENV/bin/python" -m pip install --quiet --disable-pip-version-check --only-binary=:all: --upgrade mediapipe opencv-python \
  || echo "  aviso: mediapipe nao instalou; a /vsl usa legenda fixa"

# ---------- 6. Modelos ----------
passo 6 "Baixando o modelo de transcricao (uns 2 GB, so na primeira vez)"
"$VENV/bin/python" -c "from faster_whisper import WhisperModel; [WhisperModel(m, device='cpu', compute_type='int8') for m in ('small', 'medium')]; print('  ok: modelos prontos')"

# ---------- 7. Skills ----------
passo 7 "Instalando as skills do Oney"
mkdir -p "$KIT/.claude/skills"
if [ -d "$PACOTE/skills-mac" ]; then
  cp -R "$PACOTE/skills-mac/." "$KIT/.claude/skills/"
elif [ -d "$PACOTE/skills" ]; then
  cp -R "$PACOTE/skills/." "$KIT/.claude/skills/"
elif grep -q "^__PACOTE_SKILLS__$" "$ARQ"; then
  # versao de um arquivo so: as skills vem dentro deste proprio arquivo, depois da marca
  "$ENV/bin/python3.12" - "$ARQ" "$KIT/.claude/skills" <<'PY'
import base64, io, sys, tarfile
dados = open(sys.argv[1], "rb").read().split(b"\n__PACOTE_SKILLS__\n", 1)[1]
with tarfile.open(fileobj=io.BytesIO(base64.b64decode(dados)), mode="r:gz") as t:
    t.extractall(sys.argv[2], filter="data")
PY
else
  para "Nao achei as skills. Baixe o instalador de novo pelo link do professor."
fi
echo "  ok: /reel-oney  /reel-editorial-oney  /reel-explicativo-oney  /video-colagem-oney  /anuncios-oney  /vsl"

# ---------- 8. Conferencia ----------
passo 8 "Conferindo"
cd "$KIT" && npm run setup
"$VENV/bin/python" -c "import faster_whisper" && echo "  ok: transcricao"
mkdir -p "$KIT/meus-videos"

# ---------- 9. Teste ----------
passo 9 "Teste: criando um video de 5 segundos"
TESTE="$KIT/video-projects/teste-instalacao"
mkdir -p "$TESTE"
if [ -f "$PACOTE/teste-instalacao/index.html" ]; then cp "$PACOTE/teste-instalacao/index.html" "$TESTE/"
elif grep -q "^__TESTE_HTML__$" "$ARQ"; then sed -n '/^__TESTE_HTML__$/,/^__FIM_TESTE__$/p' "$ARQ" | sed '1d;$d' > "$TESTE/index.html"
fi
cp "$KIT/node_modules/gsap/dist/gsap.min.js" "$TESTE/"
MP4="$KIT/meus-videos/teste-instalacao.mp4"
(cd "$KIT" && npx hyperframes render "$TESTE" -o "$MP4" --quiet)
[ -f "$MP4" ] || para "O video de teste nao foi criado. Mande o arquivo $LOG para o suporte."
echo "  ok: video de teste em $MP4"
open -R "$MP4" 2>/dev/null || true

trap - ERR
echo
echo "PRONTO!"
echo "O video de teste abriu no Finder: se ele tocar, esta tudo instalado."
echo "1. Feche o app do Claude por completo (Cmd+Q) e abra de novo."
echo "2. No Claude: aba Code > escolha a pasta hyperframes-student-kit (fica na sua pasta de usuario)."
echo "3. Coloque seu video na pasta: $KIT/meus-videos"
echo "4. Digite: /reel-oney meus-videos/nome-do-video.mp4"
echo "5. Higgsfield (aula da VSL): no Claude, escreva: Configura a minha chave da Higgsfield"
exit 0
