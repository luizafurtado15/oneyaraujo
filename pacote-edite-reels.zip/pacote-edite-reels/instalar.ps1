# Instalador do pacote "Edite Reels com o Claude" (Windows 10/11).
# Rode pelo INSTALAR.bat (duplo clique) ou peca ao Claude. Pode rodar de novo sem problema: o que ja existe e pulado.
#   instalar.ps1 -Diagnostico   so confere o computador (1 minuto) e diz se e compativel; nao instala nada
# Tudo o que aparece na tela tambem vai para %USERPROFILE%\edite-reels-instalacao.log (mande ao suporte se der erro).
param([switch]$Diagnostico)
$ErrorActionPreference = "Stop"
$Pacote = $PSScriptRoot
$Kit = Join-Path $env:USERPROFILE "hyperframes-student-kit"
$Venv = Join-Path $env:USERPROFILE ".venvs\whisper"
$Log = Join-Path $env:USERPROFILE "edite-reels-instalacao.log"
if ($env:EDITE_REELS_TESTE) { $Kit = Join-Path $env:EDITE_REELS_TESTE "kit"; $Venv = Join-Path $env:EDITE_REELS_TESTE "venv" }  # so para testar
$Total = 8

function Passo($n, $texto) { $script:PassoAtual = "$n/$Total - $texto"; Write-Host ""; Write-Host "[$n/$Total] $texto" -ForegroundColor Yellow }
function AtualizaPath {
  $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
}
# Um comando so conta se RODA de verdade (o Windows tem um "python" falso que abre a Microsoft Store).
function Funciona($cmd, [string[]]$argv) {
  try { $null = & $cmd @argv 2>$null; return ($LASTEXITCODE -eq 0) } catch { return $false }
}
function AchaPython {
  $locais = @(
    (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"),
    "C:\Program Files\Python312\python.exe"
  )
  foreach ($p in $locais) { if (Test-Path $p) { return $p } }
  if (Funciona "py" @("-3.12", "--version")) { return "py" }
  return $null
}
# Programa externo que falhou para a instalacao (o PowerShell sozinho seguiria em frente).
function Roda([scriptblock]$bloco, $oque) {
  & $bloco
  if ($LASTEXITCODE -ne 0) { throw "$oque falhou (codigo $LASTEXITCODE)" }
}
# Janela aberta pelo INSTALAR.bat espera o Enter; rodando pelo Claude (sem teclado) nao espera.
function Interativo { try { return ([Environment]::UserInteractive -and -not [Console]::IsInputRedirected) } catch { return $false } }
function Versao($cmd, [string[]]$argv) {
  try { $v = @(& $cmd @argv 2>$null); if ($LASTEXITCODE -eq 0 -and $v.Count) { return ("$($v[0])".Trim() -replace "^git version ", "") } } catch {}
  return $null
}

# ---------- Diagnostico (sempre roda primeiro) ----------
function Diagnostico {
  $os = Get-CimInstance Win32_OperatingSystem
  $build = [int]$os.BuildNumber
  $nome = if ($build -ge 22000) { "Windows 11" } else { "Windows 10" }
  $livre = [math]::Floor((Get-PSDrive -Name $env:USERPROFILE.Substring(0, 1)).Free / 1GB)
  $net = $false; try { $null = Invoke-WebRequest -Uri "https://github.com" -Method Head -TimeoutSec 15 -UseBasicParsing; $net = $true } catch {}
  $wg = [bool](Get-Command winget -ErrorAction SilentlyContinue)
  $linhas = @(
    @("Sistema", "$nome (build $build)", ($build -ge 17763)),
    @("Espaco livre", "$livre GB", ($livre -ge 5)),
    @("Internet", $(if ($net) { "ok" } else { "sem acesso ao github.com" }), $net),
    @("Instalador do Windows (winget)", $(if ($wg) { "ok" } else { "falta" }), $wg)
  )
  $prog = @(
    @("Node.js", (Versao "node" @("--version"))),
    @("Git", (Versao "git" @("--version"))),
    @("FFmpeg", $(if (Funciona "ffmpeg" @("-version")) { "ok" } else { $null })),
    @("Python 3.12", $(if (AchaPython) { "ok" } else { $null })),
    @("Kit de edicao", $(if (Test-Path (Join-Path $Kit "package.json")) { "ok" } else { $null })),
    @("Transcricao (Whisper)", $(if (Test-Path (Join-Path $Venv "Scripts\python.exe")) { "ok" } else { $null })),
    @("Skills do Oney", $(if (Test-Path (Join-Path $Kit ".claude\skills\reel-oney")) { "ok" } else { $null }))
  )
  Write-Host ""
  Write-Host "DIAGNOSTICO" -ForegroundColor Cyan
  foreach ($l in $linhas) { Write-Host ("  {0,-32} {1,-26} {2}" -f $l[0], $l[1], $(if ($l[2]) { "OK" } else { "PROBLEMA" })) }
  foreach ($p in $prog) { Write-Host ("  {0,-32} {1,-26} {2}" -f $p[0], $(if ($p[1]) { $p[1] } else { "-" }), $(if ($p[1]) { "PRONTO" } else { "FALTA" })) }
  $ok = -not ($linhas | Where-Object { -not $_[2] })
  Write-Host ""
  if ($ok) { Write-Host "COMPATIVEL: este computador pode instalar o kit." -ForegroundColor Green }
  else {
    Write-Host "NAO COMPATIVEL: resolva os itens com PROBLEMA antes de instalar." -ForegroundColor Red
    if ($build -lt 17763) { Write-Host "  Atualize o Windows em Configuracoes > Windows Update." }
    if ($livre -lt 5) { Write-Host "  Libere pelo menos 5 GB no disco." }
    if (-not $wg) { Write-Host "  Abra a Microsoft Store e atualize o 'Instalador de Aplicativo'." }
  }
  return $ok
}

if ($Diagnostico) { $null = Diagnostico; exit 0 }

Start-Transcript -Path $Log -Append | Out-Null
$PassoAtual = "inicio"
try {
  if (-not (Diagnostico)) { throw "computador nao compativel (veja o diagnostico acima)" }

  Passo 1 "Programas base (Node, Git, FFmpeg, Python)"
  Write-Host "  Se o Windows perguntar se pode fazer alteracoes, clique em SIM."
  $apps = @(
    @{ id = "OpenJS.NodeJS.LTS";  ok = { Funciona "node" "--version" } },
    @{ id = "Git.Git";            ok = { Funciona "git" "--version" } },
    @{ id = "Gyan.FFmpeg";        ok = { Funciona "ffmpeg" "-version" } },
    @{ id = "Python.Python.3.12"; ok = { [bool](AchaPython) } }
  )
  foreach ($a in $apps) {
    if (& $a.ok) { Write-Host "  ok: $($a.id) ja instalado" }
    else {
      Write-Host "  instalando $($a.id)..."
      winget install --id $a.id -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
      AtualizaPath
      if (-not (& $a.ok)) { throw "$($a.id) nao instalou" }
    }
  }
  $Py = AchaPython

  Passo 2 "Kit de edicao (HyperFrames)"
  if (-not (Test-Path (Join-Path $Kit "package.json"))) {
    if (Test-Path $Kit) { Rename-Item $Kit "$Kit.incompleto-$(Get-Date -Format yyyyMMddHHmmss)" }
    # longpaths: alguns arquivos de exemplo do kit tem caminho comprido (o Windows trava em 260 letras)
    Roda { git -c core.longpaths=true clone --depth 1 https://github.com/nateherkai/hyperframes-student-kit.git $Kit } "baixar o kit"
    Roda { git -C $Kit config core.longpaths true } "configurar o kit"
  } else { Write-Host "  ok: kit ja existe em $Kit" }
  Push-Location $Kit
  Roda { npm ci --no-audit --no-fund } "instalar as dependencias do kit"

  Passo 3 "Navegador de renderizacao"
  Roda { npx --yes hyperframes browser ensure } "instalar o navegador de render"
  Pop-Location

  Passo 4 "Transcricao local (Whisper)"
  if (-not (Test-Path (Join-Path $Venv "Scripts\python.exe"))) {
    if ($Py -eq "py") { Roda { py -3.12 -m venv $Venv } "criar o ambiente do Whisper" } else { Roda { & $Py -m venv $Venv } "criar o ambiente do Whisper" }
  }
  $VPy = Join-Path $Venv "Scripts\python.exe"
  Roda { & $VPy -m pip install --quiet --disable-pip-version-check --upgrade pip faster-whisper onnxruntime } "instalar o Whisper"
  # /vsl: rastreio do rosto para a legenda que segue a cabeca (se falhar, o resto continua funcionando)
  & $VPy -m pip install --quiet --disable-pip-version-check --upgrade mediapipe opencv-python
  if ($LASTEXITCODE -ne 0) { Write-Host "  aviso: mediapipe nao instalou; a /vsl usa legenda fixa" -ForegroundColor Yellow }

  Passo 5 "Baixando o modelo de transcricao (uns 2 GB, so na primeira vez)"
  Roda { & $VPy -c "from faster_whisper import WhisperModel; [WhisperModel(m, device='cpu', compute_type='int8') for m in ('small', 'medium')]; print('  ok: modelos prontos')" } "baixar o modelo de transcricao"

  Passo 6 "Instalando as skills do Oney"
  $Destino = Join-Path $Kit ".claude\skills"
  New-Item -ItemType Directory -Force $Destino | Out-Null
  Copy-Item -Recurse -Force (Join-Path $Pacote "skills\*") $Destino
  Write-Host "  ok: /reel-oney  /reel-editorial-oney  /reel-explicativo-oney  /video-colagem-oney  /anuncios-oney  /vsl"

  Passo 7 "Conferindo"
  Push-Location $Kit
  Roda { npm run setup } "conferir o kit"
  Pop-Location
  $MeusVideos = Join-Path $Kit "meus-videos"
  New-Item -ItemType Directory -Force $MeusVideos | Out-Null

  Passo 8 "Teste: criando um video de 5 segundos"
  $Teste = Join-Path $Kit "video-projects\teste-instalacao"
  New-Item -ItemType Directory -Force $Teste | Out-Null
  Copy-Item -Force (Join-Path $Pacote "teste-instalacao\index.html") $Teste
  Copy-Item -Force (Join-Path $Kit "node_modules\gsap\dist\gsap.min.js") $Teste
  $Mp4 = Join-Path $MeusVideos "teste-instalacao.mp4"
  Push-Location $Kit
  Roda { npx hyperframes render $Teste -o $Mp4 --quiet } "renderizar o video de teste"
  Pop-Location
  if (-not (Test-Path $Mp4)) { throw "o video de teste nao foi criado" }
  Write-Host "  ok: video de teste em $Mp4"
  Start-Process explorer.exe "/select,`"$Mp4`""
}
catch {
  Write-Host ""
  Write-Host "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" -ForegroundColor Red
  Write-Host "  Deu erro no passo [$PassoAtual]: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "  1. Confira a internet e rode o instalador de novo (ele continua de onde parou)."
  Write-Host "  2. Se o erro repetir, mande para o suporte o arquivo:"
  Write-Host "     $Log"
  Write-Host "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" -ForegroundColor Red
  Stop-Transcript | Out-Null
  if (Interativo) { Read-Host "Aperte Enter para fechar" }
  exit 1
}

Write-Host ""
Write-Host "PRONTO!" -ForegroundColor Green
Write-Host "O video de teste abriu numa janela: se ele tocar, esta tudo instalado."
Write-Host "1. Feche o Claude por completo (botao direito no icone do Claude perto do relogio > Sair) e abra de novo."
Write-Host "2. No Claude: aba Code > escolha a pasta $Kit"
Write-Host "3. Coloque seu video na pasta: $Kit\meus-videos"
Write-Host "4. Digite: /reel-oney meus-videos\nome-do-video.mp4"
Write-Host "5. Higgsfield (aula da VSL): no Claude, escreva: Configura a minha chave da Higgsfield"
Write-Host ""
Stop-Transcript | Out-Null
if (Interativo) { Read-Host "Aperte Enter para fechar" }
