# Edite Reels com o Claude — comece aqui (Windows e Mac)

## Antes de tudo
- **Windows 10 ou 11**, ou **Mac com macOS 12 (Monterey) ou mais novo** (chip M ou Intel).
  No Mac, veja a versão no menu da maçã › **Sobre Este Mac**.
- Uns **5 GB livres** e internet boa.
- Assinatura do **Claude Pro** (US$ 20/mês, edita em média 8 a 15 vídeos por mês)
  ou **Max** (US$ 100/mês, edita mais de 40). Assine em claude.ai.
- App do Claude instalado: **claude.ai/download** (entre com a conta do plano).

## Instalar (uma vez só, 20 a 40 minutos): o Claude instala
1. Deixe este pacote (`pacote-edite-reels.zip`) na pasta **Downloads**. Não precisa extrair.
2. Abra o app do Claude → aba **Code** → escolha a pasta **Downloads**.
   No Mac, se aparecer um aviso pedindo acesso à pasta, clique em **OK** (ou **Permitir**).
3. Copie, cole e envie esta mensagem:

> Instala para mim o pacote Edite Reels que está nesta pasta (pacote-edite-reels.zip).
> 1. Extraia o pacote e faça primeiro o diagnóstico: rode o instalador do meu sistema só no modo diagnóstico
>    (Windows: instalar.ps1 -Diagnostico · Mac: bash instalar-mac.sh --diagnostico) e me diga se o meu computador
>    é compatível, o que já está pronto e o que falta.
> 2. Se for compatível, rode o instalador completo em segundo plano (Windows: powershell -ExecutionPolicy Bypass
>    -File instalar.ps1 · Mac: bash instalar-mac.sh) e acompanhe o arquivo edite-reels-instalacao.log da minha pasta
>    de usuário até aparecer PRONTO!. Me explique cada etapa em palavras simples.
> 3. Se der erro, leia esse registro, corrija só o que deu errado e rode de novo (ele continua de onde parou).
> 4. No final o instalador cria um vídeo de teste de 5 segundos e abre a pasta dele. Confirme que o vídeo existe e
>    me diga o que fazer depois.

4. Clique em **Permitir** sempre que o Claude pedir. Se o Windows perguntar se pode fazer alterações, clique em **Sim**.
   Deixe o computador na tomada; notebook, não feche a tampa.
5. Quando terminar, o vídeo **teste-instalacao.mp4** abre numa janela. Se ele tocar, está tudo instalado.

**Deu erro e o Claude não resolveu?** Envie:
> Deu este erro na instalação: [cole aqui]. Me explique a causa em palavras simples, corrija só o que está
> relacionado e continue a instalação de onde parou. Não apague os meus arquivos.

**Fechou o Claude no meio?** Abra de novo na pasta Downloads e envie:
> Eu fechei o Claude no meio da instalação do pacote Edite Reels. Veja o que já foi instalado, não reinstale o que
> já funciona e continue de onde parou. No final, confira o vídeo de teste de 5 segundos.

Mesmo assim não foi? Mande para o suporte o arquivo **edite-reels-instalacao.log**, que fica na sua pasta de usuário
(Windows: `C:\Users\seu-nome` · Mac: Finder → menu Ir → Início).

### Prefere instalar sem o Claude?
- **Windows:** botão direito no zip → **Extrair tudo** → dois cliques em `INSTALAR.bat`. Tela azul "O Windows protegeu
  o computador"? **Mais informações** → **Executar assim mesmo**.
- **Mac:** dois cliques no zip → dois cliques em `INSTALAR-MAC.command` (ou, no Terminal, `bash` + espaço + arraste o
  `instalar-mac.sh` + Enter). No Mac a instalação não pede senha.

## Editar um vídeo
1. Feche o Claude por completo (Windows: botão direito no ícone do Claude perto do relógio → **Sair** · Mac: **Cmd + Q**)
   e abra de novo → aba **Code** → escolha a pasta `hyperframes-student-kit` (fica na sua pasta de usuário).
   Não achou? Peça ao Claude: *"Encontra para mim no meu computador a pasta hyperframes-student-kit e abre ela aqui na nossa sessão."*
2. Coloque o vídeo gravado em `hyperframes-student-kit\meus-videos`.
3. Digite um destes comandos (no Mac use barra normal: `meus-videos/video.mp4`).
   Também dá para copiar o caminho do vídeo (Windows: botão direito → **Copiar como caminho** · Mac: botão direito com
   a tecla Option → **Copiar … como Caminho**) e colar no Claude.
   Para testar, digite só `/`: se aparecerem os comandos abaixo, está tudo certo.

| Comando | Estilo |
|---|---|
| `/reel-oney meus-videos\video.mp4` | Editado no celular: legenda palavra por palavra, prints acima da cabeça |
| `/reel-editorial-oney meus-videos\video.mp4` | Editorial: letra serifada, cards, cara de "editado por IA" |
| `/reel-explicativo-oney meus-videos\video.mp4` | Explicativo/notícia: imagens reais em cima, você embaixo |
| `/video-colagem-oney meus-videos\video.mp4` | Colagem: muito ilustrado, fotos recortadas, títulos atrás de você, provas reais |
| `/anuncios-oney meus-videos\video.mp4` | Anúncio: headline nos 5 primeiros segundos e depois esquemas animados que mostram o que você fala |
| `/vsl meus-videos\video.mp4` | VSL / vídeo de venda: apresentador + interface animada; opcional trocar roupa e cenário com a Higgsfield |

Na primeira vez o Claude pergunta seu nome, seu @ e onde ficam seus prints. Responda uma vez só.
Quando o Claude pedir permissão para rodar um comando, clique em **Permitir**.

## VSL e troca de roupa/cenário com a Higgsfield (opcional)
Comando: `/vsl meus-videos\video.mp4` — vídeo de venda vertical no estilo do Oney (dois visuais: roxo/laranja ou clean).
Para trocar a sua roupa e o cenário em alguns trechos (ex.: "me coloca de jaleco num consultório"), a VSL usa a Higgsfield:
1. Crie a conta em **open.higgsfield.ai** (é o site da API, não o app higgsfield.ai) e coloque saldo em **Top up / Add funds**.
   O saldo do app não vale aqui. Um trecho de 10 s sai por volta de US$ 1; US$ 10 dá para testar bastante.
2. Em **API keys** › **Create API key** › nome "claude" › **Create key** › **Copy API key** (a chave aparece uma vez só).
3. No Claude, escreva: *"Configura a minha chave da Higgsfield. Abre o arquivo onde eu colo ela."* — cole a chave na linha
   indicada, salve com Ctrl+S e feche. Depois: *"Testa se a chave da Higgsfield está funcionando."*
4. No pedido, fale **"Usa a Higgsfield"**, diga a frase exata onde a troca começa e descreva roupa e cenário com 2 ou 3 objetos:
   *"/vsl meus-videos\anuncio.mp4 Usa a Higgsfield. Quando eu falar 'se você é médico', me coloca de jaleco branco num
   consultório."* Cada trecho tem de 3 a 15 s. O Claude mostra o custo e pede o seu OK antes de gerar.
A chave é como a senha do seu cartão: não mande em grupo, não poste print, não cole em outro lugar.

## Pedir ajustes (é só falar)
- "Tira a parte em que eu falo do preço."
- "Coloca o print do meu perfil quando eu falo de seguidores."
- "Deixa a legenda mais pra baixo."
- "Pode renderizar a versão final."

O vídeo pronto fica em `video-projects\<nome>\renders\`.
